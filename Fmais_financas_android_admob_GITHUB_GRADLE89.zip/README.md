# F+ Finanças — Android + AdMob

Projeto Android pronto para GitHub Actions.

## AdMob configurado
- App ID: ca-app-pub-8879850211172338~2013596807
- Banner: ca-app-pub-8879850211172338/3651866127

## Build no GitHub
1. Envie o conteúdo deste ZIP para a raiz do repositório.
2. Abra Actions.
3. Execute "Build F+ Finanças Android".
4. Baixe o artefato `Fmais-financas-debug`.

O projeto usa Android Gradle Plugin 8.7.3 + Gradle 8.9 + Java 17.
