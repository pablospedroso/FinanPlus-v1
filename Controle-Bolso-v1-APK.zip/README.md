# Controle Bolso

Projeto Android real (WebView) para gerar o APK do Controle Bolso.

O ícone do aplicativo foi atualizado para a opção 3: gráfico de crescimento em azul com seta verde e moeda.

O workflow em `.github/workflows/build-apk.yml` consegue compilar tanto o projeto colocado diretamente na raiz do GitHub quanto este ZIP colocado no repositório.
