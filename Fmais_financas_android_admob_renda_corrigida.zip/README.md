# F+ Finanças Android + AdMob

- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Java 17
- Debug: Google banner de teste
- Release: bloco real da AdMob
- App ID: ca-app-pub-8879850211172338~2013596807
- Banner real: ca-app-pub-8879850211172338/3651866127

O APK Debug usa o bloco oficial de teste do Google para evitar tráfego inválido durante desenvolvimento. O APK Release usa o bloco real configurado no projeto.
