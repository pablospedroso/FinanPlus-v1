# F+ Finanças

Projeto Android do F+ Finanças, com a interface web local carregada em um WebView.

## GitHub

Envie **todos os arquivos desta pasta** para o repositório GitHub.

O workflow em `.github/workflows/build-apk.yml` gera o APK automaticamente pelo GitHub Actions. O projeto enviado aqui é o **código-fonte**, não um APK.

## Informações do desenvolvedor

- Grupo: Facilita Mais | F+ 🚀
- Instagram pessoal: @pablo_spedroso
- Instagram Grupo Facilita Mais: @facilitamaisgrupo
