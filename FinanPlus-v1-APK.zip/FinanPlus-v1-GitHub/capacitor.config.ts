import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.finanplus.v1',
  appName: 'FinanPlus-v1-APK',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
