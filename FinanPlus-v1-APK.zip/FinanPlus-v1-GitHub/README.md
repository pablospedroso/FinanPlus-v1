# FinanPlus-v1-APK

Projeto do aplicativo Finan+ v1, preparado para gerar um APK Android pelo GitHub Actions.

## Como gerar o APK pelo GitHub

1. Envie todos os arquivos deste projeto para a raiz do seu repositório GitHub.
2. Abra a aba **Actions**.
3. Selecione **Build APK - Finan+ v1**.
4. Toque em **Run workflow** para iniciar manualmente.
5. Aguarde o processo terminar com o símbolo verde.
6. Abra a execução concluída e procure a seção **Artifacts**.
7. Baixe **FinanPlus-v1-APK**.

O APK gerado é uma versão de teste (`debug`).

## Estrutura

- `www/index.html` — aplicativo Finan+.
- `capacitor.config.ts` — configuração do aplicativo Android.
- `package.json` — dependências do Capacitor.
- `.github/workflows/build-apk.yml` — automação de geração do APK.
