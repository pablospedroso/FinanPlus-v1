# FinanPlus-v1-APK

Projeto Android que transforma o `index.html` original do Finan+ v1 em um aplicativo instalável.

## O que foi feito
- O HTML original foi mantido como a interface do app.
- O app usa Android WebView para executar o conteúdo offline.
- JavaScript e `localStorage` ficam habilitados, preservando os dados locais usados pelo HTML.
- Links externos, como redes sociais, abrem no navegador.
- Tela em modo retrato.
- Barras de status/navegação usam o fundo escuro do app para evitar a interface invadir a área da bateria.
- Workflow do GitHub Actions gera `FinanPlus-v1-APK.apk`.

## Como gerar no GitHub
1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. Abra **Actions**.
4. Execute **Build FinanPlus APK** manualmente em **Run workflow**.
5. Ao terminar, abra a execução e baixe o artefato **FinanPlus-v1-APK**.
6. Dentro dele estará `FinanPlus-v1-APK.apk`, pronto para instalar no Android.

O projeto não depende de PWA, navegador instalado ou servidor local para funcionar.
