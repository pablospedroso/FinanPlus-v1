import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.finanplus.v1',
  appName: 'Finan+ v1',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
