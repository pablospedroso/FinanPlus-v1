# Finan+ v1

Aplicativo de finanças pessoais baseado no protótipo HTML final.

## Estrutura

- `www/index.html` — aplicativo web do Finan+
- `capacitor.config.ts` — configuração do aplicativo Android
- `.github/workflows/build-apk.yml` — gera um APK debug automaticamente no GitHub Actions

## Gerar APK pelo GitHub

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Abra a aba **Actions**.
4. Execute **Build APK - Finan+ v1**.
5. Ao terminar, baixe o artefato `FinanPlus-v1-debug-apk`.

O projeto Android é criado durante o workflow, então não é necessário enviar uma pasta `android` pronta para o GitHub.
