# F+ Finanças Android + AdMob

Este ZIP contém o projeto Android completo do F+ Finanças.

## Como usar no GitHub

Você pode enviar este ZIP para a raiz do repositório. O workflow em `.github/workflows/build.yml` encontra o ZIP, extrai o projeto e executa o build automaticamente.

O workflow gera:
- APK Debug (usa o anúncio de teste oficial do Google)
- APK Release (usa o bloco AdMob real configurado)
- AAB Release (formato para Google Play)

## Configuração AdMob
- App ID: `ca-app-pub-8879850211172338~2013596807`
- Banner real: `ca-app-pub-8879850211172338/3651866127`
- Banner de teste Debug: `ca-app-pub-3940256099942544/9214589741`

## Ambiente
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35
- targetSdk 35
- minSdk 23
