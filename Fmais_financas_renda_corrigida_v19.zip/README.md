# F+ Finanças — versão sem anúncios

Projeto Android completo para GitHub Actions.

- Sem AdMob e sem anúncios.
- Calendário de vale usa o calendário temático interno do F+ em vez do seletor nativo branco do Android.
- Contas pagas ficam com indicador verde.
- Vales seguem o ciclo Virou o vale (amarelo) → Disponível (verde) → Gasto (vermelho).
- Mantida a correção do marcador de fim de benefício no calendário.
- Ícone do aplicativo preservado.
