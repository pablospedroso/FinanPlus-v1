# F+ Finanças — Android + AdMob real

Baseado no ZIP de teste Chrome enviado pelo usuário.

AdMob configurado:
- App ID: ca-app-pub-8879850211172338~2013596807
- Banner: ca-app-pub-8879850211172338/3651866127

O banner fica acima do WebView, sem sobrepor a navegação do aplicativo.

Importante: anúncios reais podem demorar a começar a servir. Durante testes, não clique nos próprios anúncios; tráfego inválido pode prejudicar a conta do AdMob.
