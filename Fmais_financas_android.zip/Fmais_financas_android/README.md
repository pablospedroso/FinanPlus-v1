# F+ Finanças — projeto Android

Este ZIP é um projeto Android completo. Diferente do ZIP anterior, ele contém `settings.gradle`, `build.gradle` e `app/`, portanto pode ser compilado pelo GitHub Actions.

## Recursos da versão
- Contas pagas: indicador lateral fica verde.
- Vale: ciclo de status `Virou o vale` → `Disponível` → `Gasto`, com amarelo/verde/vermelho.
- Calendário: marcador amarelo para o fim de benefício, usando a data final cadastrada.
- Informações do criador com o texto solicitado.

## GitHub Actions
O workflow em `.github/workflows/build.yml` gera `app-debug.apk` e disponibiliza o APK em Artifacts.
