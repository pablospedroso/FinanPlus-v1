# Finan+ v1 — no custom shrinking rules required.
