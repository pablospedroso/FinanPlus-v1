
function toggleBalanceVisibility(){
  const el=document.getElementById("balance");
  if(!el) return;
  if(el.dataset.hidden==="1"){el.textContent=el.dataset.value||"R$ 0,00";el.dataset.hidden="0";}
  else{el.dataset.value=el.textContent;el.textContent="R$ •••••";el.dataset.hidden="1";}
}

const money=v=>Number(v||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const today=new Date();
const ymNow=()=>today.getFullYear()+"-"+String(today.getMonth()+1).padStart(2,"0");
let userName="",userEmail="",expenses=[],incomes=[],goals=[],monthlyLimit=0,currentFilter="all",selectedCalDay=null;

function key(s){return "fp1_"+s+"_"+userEmail.toLowerCase().trim()}
function save(){
 localStorage.setItem(key("expenses"),JSON.stringify(expenses));
 localStorage.setItem(key("incomes"),JSON.stringify(incomes));
 localStorage.setItem(key("goals"),JSON.stringify(goals));
 localStorage.setItem(key("limit"),String(monthlyLimit));
 localStorage.setItem("fp1_session",JSON.stringify({name:userName,email:userEmail}));
}
function loadAccount(email,name){
 userEmail=email.toLowerCase().trim(); userName=name.trim();
 expenses=JSON.parse(localStorage.getItem(key("expenses"))||"[]");
 incomes=JSON.parse(localStorage.getItem(key("incomes"))||"[]");
 goals=JSON.parse(localStorage.getItem(key("goals"))||"[]");
 monthlyLimit=Number(localStorage.getItem(key("limit"))||0);
 save();
}
function showLogin(){document.getElementById("startScreen").classList.add("hidden");document.getElementById("loginScreen").style.display="flex"}
function login(){
 const n=document.getElementById("loginName").value.trim();
 if(!n){toast("Digite seu nome ou apelido");return}
 // O acesso do protótipo é identificado apenas pelo nome informado.
 const accountKey=n.toLowerCase().replace(/\s+/g," ").trim();
 const old=JSON.parse(localStorage.getItem("fp1_session")||"null");
 loadAccount(accountKey,n);
 localStorage.setItem("fp1_logged","1");
 document.getElementById("loginScreen").style.display="none";document.getElementById("app").style.display="flex";render();
 toast(old&&old.email===accountKey?"Dados carregados!":"Vamos começar!");
}
function logout(){localStorage.removeItem("fp1_logged");localStorage.removeItem("fp1_session");location.reload()}
function changeName(){const n=prompt("Novo nome ou apelido:",userName);if(n&&n.trim()){userName=n.trim();save();render();toast("Perfil atualizado")}}
function go(page){
 closeAllOverlays();
 document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
 document.getElementById(page).classList.add("active");
 document.querySelectorAll(".nav button").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 document.querySelectorAll("#mobileBottomNav button[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 const t={home:[`Olá, ${userName||"seu nome"} 👋`,"Aqui está o resumo das suas finanças."],income:["Minha renda","Cadastre quanto recebe e o dia da entrada."],expenses:["Minhas despesas","Escolha o tipo antes de informar o dia."],calendar:["Calendário financeiro","Acompanhe entradas e despesas por data."],charts:["Gráficos","Escolha como quer visualizar seus dados."],goals:["Metas financeiras","Crie, edite e acompanhe suas próprias metas."],more:["Minha conta","Dados da conta e configurações."],creator:["Informações do criador","Instagram pessoal e informações do criador do Finan+."]};
 document.getElementById("pageTitle").textContent=t[page][0];document.getElementById("pageSub").textContent=t[page][1];render();
}
document.querySelectorAll(".nav button").forEach(b=>b.onclick=()=>go(b.dataset.page));

function monthKey(d){return String(d).slice(0,7)}
function daysInMonth(y,m){return new Date(y,m,0).getDate()}
function expenseOccurrences(x,ym){
 const [y,m]=ym.split("-").map(Number), out=[];
 if(x.type==="frequent"||x.type==="fixed"){
   const day=Math.min(Number(x.day||1),daysInMonth(y,m));out.push({date:`${ym}-${String(day).padStart(2,"0")}`,x,part:null});
 }else if(x.type==="installment"){
   const first=new Date(x.firstDate+"T12:00:00");
   for(let i=0;i<Number(x.parts||1);i++){
     const dt=new Date(first.getFullYear(),first.getMonth()+i,Math.min(first.getDate(),28),12);
     const k=ymNow(); const wanted=`${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,"0")}`;
     if(wanted===ym) out.push({date:`${wanted}-${String(dt.getDate()).padStart(2,"0")}`,x,part:i+1});
   }
 }else{
   if(monthKey(x.date)===ym)out.push({date:x.date,x,part:null});
 }
 return out;
}
function monthlyExpenses(ym){let a=[];expenses.forEach(x=>a.push(...expenseOccurrences(x,ym)));return a}
function monthlyIncome(ym){
 const [y,m]=ym.split("-").map(Number);
 return incomes.map(x=>{const day=Math.min(Number(x.day||1),daysInMonth(y,m));const date=`${ym}-${String(day).padStart(2,"0")}`;return {date,x};}).filter(o=>!o.x.endDate||o.date<=o.x.endDate);
}
function itemHTML(x,type){
 if(type==="income")return `<div class="item"><div class="itemLeft"><div class="icon green">↥</div><div><b>${esc(x.name)}</b><small>${esc(x.type)} • todo dia ${x.day}${x.type==="Benefício"?(x.benefitFixed?" • fixo":(x.endDate?` • até ${dateBR(x.endDate)}`:"")):""}</small></div></div><div style="text-align:right"><b class="positive">+ ${money(x.value)}</b><br><button type="button" class="btn danger" style="padding:5px 8px;margin-top:5px" onclick="removeIncome(${x.id})">×</button></div></div>`;
 const typ={frequent:"Frequente",fixed:"Fixa",installment:"Parcelada",monthly:"Só este mês"}[x.type]||x.type;
 const extra=x.type==="installment"?` • ${x.parts}x • 1ª ${dateBR(x.firstDate)}`:(x.type==="monthly"?` • ${dateBR(x.date)}`:` • todo dia ${x.day}`);
 return `<div class="item"><div class="itemLeft"><div class="icon red">↘</div><div><b>${esc(x.name)}</b><small>${esc(x.cat)} • ${typ}${extra}</small></div></div><div style="text-align:right"><b class="negative">- ${money(x.value)}</b><br><button class="btn" style="padding:5px 8px;margin-top:5px" onclick="togglePaid(${x.id})">${x.paid?"Pago":"Marcar pago"}</button> <button class="btn danger" style="padding:5px 8px" onclick="removeExpense(${x.id})">×</button></div></div>`;
}
function filteredExpenses(){
 if(currentFilter==="installment")return expenses.filter(x=>x.type==="installment");
 if(currentFilter==="frequent")return expenses.filter(x=>x.type==="frequent");
 if(currentFilter==="fixed")return expenses.filter(x=>x.type==="fixed");
 return expenses;
}
function filterExpenses(f,b){currentFilter=f;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");render()}

function goalHTML(g){
 const p=g.target>0?Math.min(100,Math.round(g.saved/g.target*100)):0;
 const remaining=Math.max(0,g.target-g.saved);
 return `<div class="goal"><div class="goalTop"><b>🎯 ${esc(g.name)}</b><b>${p}%</b></div><small>${money(g.saved)} já guardados de ${money(g.target)}${remaining>0?` • faltam ${money(remaining)}`:" • meta alcançada!"}</small><div class="progress" style="margin-top:9px"><span style="width:${p}%"></span></div><div class="goalActions"><button class="btn" onclick="editGoal(${g.id})">Editar</button><button class="btn" onclick="addSaved(${g.id})">Adicionar guardado</button><button class="btn danger" onclick="removeGoal(${g.id})">Excluir</button></div></div>`;
}
function parseGoalMoney(v){
  let raw=String(v??"").trim().replace(/\s/g,"");
  if(!raw) return 0;
  raw=raw.replace(/R\$/gi,"").trim();
  const comma=raw.lastIndexOf(","), dot=raw.lastIndexOf(".");
  if(comma>=0 && dot>=0){
    // Quando os dois separadores aparecem, o último é o decimal.
    const decimalPos=Math.max(comma,dot), intPart=raw.slice(0,decimalPos).replace(/[^0-9]/g,""), decPart=raw.slice(decimalPos+1).replace(/[^0-9]/g,"");
    return Number((intPart||"0")+"."+(decPart||"0"));
  }
  if(comma>=0){
    const intPart=raw.slice(0,comma).replace(/[^0-9]/g,""), decPart=raw.slice(comma+1).replace(/[^0-9]/g,"");
    return Number((intPart||"0")+"."+(decPart||"0"));
  }
  if(dot>=0){
    const parts=raw.split("."), last=parts[parts.length-1].replace(/[^0-9]/g,"");
    // 1.234,56 já foi tratado acima; aqui, ponto com 1–2 dígitos é decimal,
    // enquanto 3 dígitos representa separador de milhar.
    if(last.length<=2){
      const intPart=parts.slice(0,-1).join("").replace(/[^0-9]/g,"");
      return Number((intPart||"0")+"."+(last||"0"));
    }
    return Number(parts.join("").replace(/[^0-9]/g,""));
  }
  return Number(raw.replace(/[^0-9]/g,""))||0;
}
function formatGoalMoneyInput(el){
  if(!el) return;
  const n=parseGoalMoney(el.value);
  if(Number.isFinite(n)) el.value=n.toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2});
}
function setupGoalMoneyInputs(){
  document.querySelectorAll(".goalMoneyInput").forEach(el=>{
    el.addEventListener("input",()=>{
      el.value=String(el.value||"").replace(/[^0-9,.]/g,"");
    });
    el.addEventListener("focus",()=>{
      if(parseGoalMoney(el.value)===0) el.value="";
    });
    el.addEventListener("blur",()=>formatGoalMoneyInput(el));
  });
}
let editingGoalId=null,savingGoalId=null,deletingGoalId=null;
function openGoalModal(id=null){
 editingGoalId=id;const m=document.getElementById("goalModal"),name=document.getElementById("goalNameInput"),target=document.getElementById("goalTargetInput"),saved=document.getElementById("goalSavedInput"),title=document.getElementById("goalTitle");if(!m)return;
 const g=id?goals.find(x=>x.id===id):null;title.textContent=g?"Editar meta":"Nova meta";name.value=g?g.name:"";target.value=g?Number(g.target).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2}):"";saved.value=g?Number(g.saved).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2}):"";m.classList.add("open");m.setAttribute("aria-hidden","false");setTimeout(()=>{name.focus();if(g)name.select()},80);
}
function closeGoalModal(){const m=document.getElementById("goalModal");if(m){m.classList.remove("open");m.setAttribute("aria-hidden","true")}editingGoalId=null}
function saveGoalModal(){
  const nameEl=document.getElementById("goalNameInput"), targetEl=document.getElementById("goalTargetInput"), savedEl=document.getElementById("goalSavedInput");
  if(!nameEl||!targetEl||!savedEl) return;
  const name=nameEl.value.trim(), target=parseGoalMoney(targetEl.value), savedRaw=savedEl.value.trim(), saved=savedRaw===""?0:parseGoalMoney(savedRaw);
  if(!name){toast("Dê um nome para sua meta");nameEl.focus();return}
  if(!Number.isFinite(target)||target<=0){toast("Informe um valor válido para alcançar");targetEl.focus();return}
  if(!Number.isFinite(saved)||saved<0){toast("Informe quanto você já guardou");savedEl.focus();return}
  if(saved>target){toast("O valor guardado não pode ser maior que a meta");savedEl.focus();return}
  try{
    if(editingGoalId){
      const g=goals.find(x=>x.id===editingGoalId);
      if(!g){toast("Não foi possível localizar essa meta");return}
      Object.assign(g,{name,target,saved});
    }else{
      goals.push({id:Date.now()+Math.floor(Math.random()*1000),name,target,saved});
    }
    save();
    closeGoalModal();
    render();
    toast(editingGoalId?"Meta atualizada!":"Meta criada!");
  }catch(err){
    console.error(err);
    toast("Não foi possível salvar a meta. Tente novamente.");
  }
}
function addGoal(){openGoalModal()}
function editGoal(id){openGoalModal(id)}
function addSaved(id){
 const g=goals.find(x=>x.id===id);if(!g)return;savingGoalId=id;const m=document.getElementById("savedGoalModal"),i=document.getElementById("savedValueInput"),d=document.getElementById("savedGoalDesc");if(!m||!i)return;d.textContent=`Você já guardou ${money(g.saved)} para “${g.name}”. Quanto quer adicionar agora?`;i.value="";m.classList.add("open");m.setAttribute("aria-hidden","false");setTimeout(()=>{i.focus()},80);
}
function closeSavedGoalModal(){const m=document.getElementById("savedGoalModal");if(m){m.classList.remove("open");m.setAttribute("aria-hidden","true")}savingGoalId=null}
function saveSavedGoalModal(){const g=goals.find(x=>x.id===savingGoalId),v=parseGoalMoney(document.getElementById("savedValueInput").value);if(!g)return;if(!(v>0)){toast("Informe um valor válido");document.getElementById("savedValueInput").focus();return}if(g.saved+v>g.target){toast(`Esse valor ultrapassa o restante de ${money(g.target-g.saved)}`);return}g.saved+=v;save();closeSavedGoalModal();render();toast("Valor guardado atualizado!")}
function removeGoal(id){
 const g=goals.find(x=>x.id===id);
 if(!g)return;
 deletingGoalId=id;
 const m=document.getElementById("goalDeleteModal"),n=document.getElementById("goalDeleteName");
 if(!m)return;
 if(n)n.textContent=g.name;
 m.classList.add("open");m.setAttribute("aria-hidden","false");
 setTimeout(()=>document.querySelector("#goalDeleteModal .confirmDelete")?.focus(),80);
}
function closeDeleteGoalModal(){
 const m=document.getElementById("goalDeleteModal");
 if(m){m.classList.remove("open");m.setAttribute("aria-hidden","true")}
 deletingGoalId=null;
}
function confirmDeleteGoal(){
 if(!deletingGoalId)return;
 goals=goals.filter(x=>x.id!==deletingGoalId);
 save();
 closeDeleteGoalModal();
 render();
 toast("Meta excluída!");
}

function closeAllOverlays(){
  const ids=["modal","incomeModal","quickActions","iTypePicker","fDayPicker","fCatPicker","fTypePicker","goalDeleteModal"];
  ids.forEach(id=>{const el=document.getElementById(id);if(el){el.classList.remove("open");if(id==="quickActions")el.setAttribute("aria-hidden","true");if(id==="iTypePicker"||id==="fDayPicker"||id==="fCatPicker"||id==="fTypePicker")el.style.display="none";if(id==="goalDeleteModal")el.setAttribute("aria-hidden","true");}});
  const plus=document.getElementById("navPlusButton");if(plus)plus.classList.remove("open");
}
function openExpenseModal(){
 closeAllOverlays();
 const form=document.getElementById("entryForm");form.reset();
 document.getElementById("fType").value="";document.getElementById("fTypeDisplay").textContent="Selecione...";document.getElementById("fCat").value="Casa";document.getElementById("fCatDisplay").textContent="Casa";document.getElementById("fCatPicker").style.display="none";document.getElementById("fTypePicker").style.display="none";
 document.getElementById("fFirstDate").value=ymNow()+"-"+String(today.getDate()).padStart(2,"0");
 document.getElementById("fDay").value="";document.getElementById("fDayDisplay").textContent="Escolha o dia";
 setMoneyInputValue("fValue",0);
 document.getElementById("fDayPicker").style.display="none";
 pickerDate=new Date(today.getFullYear(),today.getMonth(),1);
 updateExpenseFields();renderDayPicker();
 document.getElementById("modal").classList.add("open");
}
function toggleExpenseCategoryPicker(){const p=document.getElementById("fCatPicker");if(!p)return;const open=p.style.display!=="none";document.getElementById("fTypePicker").style.display="none";document.getElementById("iTypePicker").style.display="none";p.style.display=open?"none":"block";}
function selectExpenseCategory(cat){document.getElementById("fCat").value=cat;document.getElementById("fCatDisplay").textContent=cat;document.getElementById("fCatPicker").style.display="none";}
function toggleExpenseTypePicker(){const p=document.getElementById("fTypePicker");if(!p)return;const open=p.style.display!=="none";document.getElementById("fCatPicker").style.display="none";document.getElementById("iTypePicker").style.display="none";p.style.display=open?"none":"block";}
function selectExpenseType(value,label){document.getElementById("fType").value=value;document.getElementById("fTypeDisplay").textContent=label;document.getElementById("fTypePicker").style.display="none";updateExpenseFields();}
function updateExpenseFields(){
 const t=document.getElementById("fType").value;
 const recurring=t==="frequent"||t==="fixed";
 document.getElementById("fDayWrap").style.display=recurring||t==="monthly"?"block":"none";
 document.getElementById("fFirstDateWrap").style.display=t==="installment"?"block":"none";
 document.getElementById("fPartsWrap").style.display=t==="installment"?"block":"none";
 document.getElementById("fDateLabel").textContent=t==="monthly"?"Data da despesa":"Dia do mês";
 document.getElementById("fDay").required=recurring||t==="monthly";
 document.getElementById("fDayButton").style.display=(recurring||t==="monthly")?"flex":"none";
 if(!(recurring||t==="monthly"))document.getElementById("fDayPicker").style.display="none";
}
let pickerDate=new Date(today.getFullYear(),today.getMonth(),1);
function monthName(y,m){return new Date(y,m,1).toLocaleDateString("pt-BR",{month:"long",year:"numeric"});}
function renderDayPicker(){
 const wrap=document.getElementById("fDayPicker");if(!wrap)return;
 const y=pickerDate.getFullYear(),m=pickerDate.getMonth(),first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate(),selected=Number(document.getElementById("fDay")?.value||0);
 let h=`<div class="dayPickerHead"><button type="button" onclick="shiftPickerMonth(-1)">‹</button><b>${monthName(y,m)}</b><button type="button" onclick="shiftPickerMonth(1)">›</button></div>`;
 h+=`<div class="dayPickerWeek">${["D","S","T","Q","Q","S","S"].map(d=>`<span>${d}</span>`).join("")}</div><div class="dayPickerGrid">`;
 for(let i=0;i<first;i++)h+="<span class=\"dayPickerEmpty\"></span>";
 for(let d=1;d<=days;d++){const active=d===selected;const isToday=y===today.getFullYear()&&m===today.getMonth()&&d===today.getDate();h+=`<button type="button" class="dayPickerDay ${active?"selected":""} ${isToday?"today":""}" onclick="selectPickerDay(${d})">${d}</button>`;}
 h+='</div><div class="dayPickerHint">Toque no dia em que a conta deve ser paga.</div>';wrap.innerHTML=h;
}
function toggleDayPicker(){
 const t=document.getElementById("fType").value;if(!(t==="frequent"||t==="fixed"||t==="monthly"))return;
 const wrap=document.getElementById("fDayPicker");const open=wrap.style.display!=="none";wrap.style.display=open?"none":"block";if(!open)renderDayPicker();
}
function shiftPickerMonth(delta){pickerDate=new Date(pickerDate.getFullYear(),pickerDate.getMonth()+delta,1);renderDayPicker();}
function selectPickerDay(day){
 const input=document.getElementById("fDay"),display=document.getElementById("fDayDisplay");if(!input||!display)return;
 input.value=day;display.textContent=`Dia ${day}`;document.getElementById("fDayPicker").style.display="none";
}
function closeModal(){document.getElementById("modal").classList.remove("open")}
function dateBR(s){return new Date(s+"T12:00:00").toLocaleDateString("pt-BR")}
function parseMoneyInput(id){const el=document.getElementById(id);if(!el)return 0;const digits=String(el.value||"").replace(/\D/g,"");return Number(digits||"0")/100;}
function setMoneyInputValue(id,value){const el=document.getElementById(id);if(!el)return;const cents=Math.max(0,Math.round(Number(value||0)*100));el.value=(cents/100).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2});}
function moneyInputHandler(e){
 const el=e.target;const digits=String(el.value||"").replace(/\D/g,"").replace(/^0+(?=\d)/,"");const cents=Number(digits||"0");el.value=(cents/100).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2});
 try{el.setSelectionRange(el.value.length,el.value.length)}catch(_){ }
}
function setupMoneyInputs(){document.querySelectorAll(".moneyInput").forEach(el=>{el.addEventListener("input",moneyInputHandler);el.addEventListener("focus",()=>{if(parseMoneyInput(el.id)===0)setMoneyInputValue(el.id,0);setTimeout(()=>{try{el.setSelectionRange(el.value.length,el.value.length)}catch(_){ }},0)});});}
function submitExpenseForm(){
 const btn=document.getElementById("expenseSubmitButton");if(btn.dataset.busy==="1")return;btn.dataset.busy="1";
 try{
  const t=document.getElementById("fType").value;if(!t){toast("Escolha o tipo da despesa primeiro");return}
  const value=parseMoneyInput("fValue");if(!(value>0)){toast("Informe um valor maior que zero");return}
  const x={id:Date.now(),name:document.getElementById("fName").value.trim(),value,cat:document.getElementById("fCat").value,type:t,paid:false,obs:document.getElementById("fObs").value.trim()};
  if(!x.name){toast("Informe o nome da despesa");return}
  if(t==="installment"){x.parts=Number(document.getElementById("fParts").value);x.firstDate=document.getElementById("fFirstDate").value;if(!x.parts||!x.firstDate){toast("Informe parcelas e primeiro pagamento");return}}
  else if(t==="monthly"){const day=Number(document.getElementById("fDay").value);if(!day){toast("Escolha o dia da despesa");return}x.date=`${ymNow()}-${String(Math.min(day,daysInMonth(today.getFullYear(),today.getMonth()+1))).padStart(2,"0")}`}
  else {x.day=Number(document.getElementById("fDay").value);if(!x.day){toast("Escolha o dia da despesa");return}}
  expenses.push(x);save();closeModal();render();toast("Despesa adicionada!");
 }finally{setTimeout(()=>{btn.dataset.busy="0"},250)}
}
function openIncomeSource(){
 closeAllOverlays();
 document.getElementById("incomeForm").reset();
 setMoneyInputValue("iValue",0);document.getElementById("iDay").value=1;
 document.getElementById("iType").value="Salário";document.getElementById("iTypeDisplay").textContent="Salário";
 document.getElementById("iTypePicker").style.display="none";
 document.getElementById("benefitOptions").style.display="none";document.getElementById("iEndDate").value="";document.getElementById("iEndDateDisplay").textContent="Escolha a data";document.getElementById("iEndDatePicker").style.display="none";setBenefitDuration(false);
 document.getElementById("incomeModal").classList.add("open");
}
function closeIncomeModal(){document.getElementById("incomeModal").classList.remove("open")}
function toggleIncomeTypePicker(){const p=document.getElementById("iTypePicker");document.getElementById("fCatPicker").style.display="none";document.getElementById("fTypePicker").style.display="none";p.style.display=p.style.display==="none"?"block":"none";}
function selectIncomeType(type){document.getElementById("iType").value=type;document.getElementById("iTypeDisplay").textContent=type;document.getElementById("iTypePicker").style.display="none";document.getElementById("benefitOptions").style.display=type==="Benefício"?"block":"none";if(type!=="Benefício")setBenefitDuration(false);}
function setBenefitDuration(temporary){
 const yes=document.getElementById("benefitTemporary"),no=document.getElementById("benefitFixed"),wrap=document.getElementById("benefitEndWrap");
 yes.classList.toggle("active",temporary);no.classList.toggle("active",!temporary);wrap.style.display=temporary?"block":"none";
 if(temporary&&!document.getElementById("iEndDate").value){
   const iso=ymNow()+"-"+String(Math.min(today.getDate(),daysInMonth(today.getFullYear(),today.getMonth()+1))).padStart(2,"0");
   document.getElementById("iEndDate").value=iso;
   const d=document.getElementById("iEndDateDisplay");if(d)d.textContent=dateBR(iso);
 }
}
function submitIncomeForm(){
 const btn=document.getElementById("incomeSubmitButton");if(btn.dataset.busy==="1")return;btn.dataset.busy="1";
 try{
  const name=document.getElementById("iName").value.trim(),value=parseMoneyInput("iValue"),day=Number(document.getElementById("iDay").value),type=document.getElementById("iType").value;
  if(!name){toast("Informe o nome da renda");return}if(!(value>0)){toast("Informe um valor maior que zero");return}if(!(day>=1&&day<=31)){toast("Informe um dia entre 1 e 31");return}
  const x={id:Date.now(),name,value,day,type};
  if(type==="Benefício"){
    const temporary=document.getElementById("benefitTemporary").classList.contains("active");
    x.benefitFixed=!temporary;
    x.endDate=temporary?document.getElementById("iEndDate").value:"";
    if(temporary&&!x.endDate){toast("Informe a data prevista para terminar");return}
  }
  incomes.push(x);save();closeIncomeModal();render();toast("Renda adicionada!");
 }finally{setTimeout(()=>{btn.dataset.busy="0"},250)}
}
let customPickerTarget="",customPickerDisplay="",customPickerWrap="",customPickerMonth=new Date(today.getFullYear(),today.getMonth(),1);
function openCustomDatePicker(targetId,displayId,pickerId){
 customPickerTarget=targetId;customPickerDisplay=displayId;customPickerWrap=pickerId;
 const current=document.getElementById(targetId)?.value;
 if(current){const d=new Date(current+"T12:00:00");customPickerMonth=new Date(d.getFullYear(),d.getMonth(),1);}else customPickerMonth=new Date(today.getFullYear(),today.getMonth(),1);
 document.querySelectorAll(".fullDatePicker").forEach(x=>{if(x.id!==pickerId)x.style.display="none"});
 const wrap=document.getElementById(pickerId);if(!wrap)return;wrap.style.display=wrap.style.display!=="none"?"none":"block";if(wrap.style.display==="block")renderCustomDatePicker();
}
function shiftCustomDatePicker(delta){customPickerMonth=new Date(customPickerMonth.getFullYear(),customPickerMonth.getMonth()+delta,1);renderCustomDatePicker();}
function selectCustomDate(iso){const input=document.getElementById(customPickerTarget),display=document.getElementById(customPickerDisplay),wrap=document.getElementById(customPickerWrap);if(!input)return;input.value=iso;if(display)display.textContent=dateBR(iso);if(wrap)wrap.style.display="none";renderCalendar();}
function renderCustomDatePicker(){
 const wrap=document.getElementById(customPickerWrap);if(!wrap)return;
 const y=customPickerMonth.getFullYear(),m=customPickerMonth.getMonth(),first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate(),selected=document.getElementById(customPickerTarget)?.value||"";
 let h=`<div class="fullDatePickerHead"><button type="button" onclick="shiftCustomDatePicker(-1)">‹</button><b>${monthName(y,m)} de ${y}</b><button type="button" onclick="shiftCustomDatePicker(1)">›</button></div>`;
 h+=`<div class="fullDatePickerWeek">${["D","S","T","Q","Q","S","S"].map(d=>`<span>${d}</span>`).join("")}</div><div class="fullDatePickerGrid">`;
 for(let i=0;i<first;i++)h+='<span class="fullDatePickerEmpty"></span>';
 for(let d=1;d<=days;d++){const iso=`${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`,sel=iso===selected,isToday=iso===ymNow()+"-"+String(today.getDate()).padStart(2,"0");h+=`<button type="button" class="fullDatePickerDay ${sel?"selected":""} ${isToday?"today":""}" onclick="selectCustomDate('${iso}')">${d}</button>`;}
 h+='</div><div class="fullDatePickerHint">Toque em uma data para selecionar.</div>';wrap.innerHTML=h;
}
setupMoneyInputs();
setupGoalMoneyInputs();

document.getElementById("entryForm").onsubmit=e=>{e.preventDefault();submitExpenseForm();};
document.getElementById("incomeForm").onsubmit=e=>{e.preventDefault();submitIncomeForm();};

function openLimitModal(){const m=document.getElementById("limitModal"),i=document.getElementById("monthlyLimitInput");if(!m||!i)return;i.value=monthlyLimit?String(monthlyLimit).replace(".",","):"";m.classList.add("open");m.setAttribute("aria-hidden","false");setTimeout(()=>{i.focus();i.select()},80)}
function closeLimitModal(){const m=document.getElementById("limitModal");if(m){m.classList.remove("open");m.setAttribute("aria-hidden","true")}}
function saveMonthlyLimit(){const i=document.getElementById("monthlyLimitInput");if(!i)return;const raw=i.value.trim().replace(/\s/g,"").replace(/\./g,"").replace(",",".");const n=Number(raw);if(raw===""||Number.isNaN(n)||n<0){toast("Informe um valor válido");i.focus();return}monthlyLimit=n;save();closeLimitModal();render();toast("Limite atualizado!")}
function setMonthlyLimit(){openLimitModal()}
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeLimitModal();closeGoalModal();closeSavedGoalModal();closeDeleteGoalModal()}});
function togglePaid(id){const x=expenses.find(x=>x.id===id);if(x){x.paid=!x.paid;save();render()}}
function removeExpense(id){expenses=expenses.filter(x=>x.id!==id);save();render();toast("Despesa removida")}
function removeIncome(id){incomes=incomes.filter(x=>x.id!==id);save();render();toast("Renda removida")}

function render(){
 const ym=ymNow(), inc=monthlyIncome(ym).reduce((a,o)=>a+o.x.value,0), exp=monthlyExpenses(ym).reduce((a,o)=>a+o.x.value,0), bal=inc-exp;
 document.getElementById("balance").textContent=money(bal);document.getElementById("incomeTotal").textContent=money(inc);document.getElementById("expenseTotal").textContent=money(exp);
 const hi=document.getElementById("heroIncome"),he=document.getElementById("heroExpense"),hb=document.getElementById("heroBills");
 if(hi)hi.textContent=money(inc); if(he)he.textContent=money(exp);
 if(hb){const totalBills=monthlyExpenses(ym).length, paidBills=monthlyExpenses(ym).filter(o=>o.x.paid).length;hb.textContent=paidBills+" de "+totalBills;}
 const si=document.getElementById("summaryIncome"),se=document.getElementById("summaryExpense");
 if(si)si.textContent=money(inc); if(se)se.textContent=money(exp);
 const sbI=document.getElementById("summaryIncomeBar"),sbE=document.getElementById("summaryExpenseBar"),tot=inc+exp;
 if(sbI&&sbE){sbI.style.width=(tot?Math.max(0,Math.min(100,inc/tot*100)):60)+"%";sbE.style.width=(tot?Math.max(0,Math.min(100,exp/tot*100)):40)+"%";}

 document.getElementById("monthlyLimit").textContent=monthlyLimit?money(monthlyLimit):"Não definido";
 document.getElementById("incomeSourcesCount").textContent=incomes.length+" entradas";document.getElementById("expenseModeHint").textContent=monthlyExpenses(ym).length+" lançamentos";
 document.getElementById("limitStatus").textContent=monthlyLimit?(exp>monthlyLimit?`Excedeu ${money(exp-monthlyLimit)}`:`Restam ${money(monthlyLimit-exp)}`):"Defina seu limite";
 document.getElementById("profileName").textContent=userName;document.getElementById("limitSetting").textContent=monthlyLimit?money(monthlyLimit):"Não definido";document.getElementById("incomePageTotal").textContent=money(inc);
 const list=filteredExpenses();document.getElementById("expenseList").innerHTML=list.length?list.map(x=>itemHTML(x,"expense")).join(""):'<div class="empty">Nenhuma despesa cadastrada.</div>';
 document.getElementById("incomeList").innerHTML=incomes.length?incomes.map(x=>itemHTML(x,"income")).join(""):'<div class="empty">Nenhuma renda cadastrada.</div>';
 const upcoming=monthlyExpenses(ym).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,5);document.getElementById("homeExpenses").innerHTML=upcoming.length?upcoming.map(o=>itemHTML({...o.x,date:o.date},"expense")).join(""):'<div class="empty">Nenhuma despesa neste mês.</div>';
 document.getElementById("homeGoals").innerHTML=goals.length?goals.slice(0,3).map(goalHTML).join(""):'<div class="empty">Nenhuma meta criada ainda.</div>';
 const goalList=document.getElementById("goalList"); if(goalList) goalList.innerHTML=goals.length?goals.map(goalHTML).join(""):'<div class="empty" style="padding:28px 15px"><div style="font-size:34px;margin-bottom:8px">🎯</div><b style="color:#fff">Sua primeira meta começa aqui</b><div style="margin-top:6px">Toque em “Criar meta” para definir o que você quer conquistar.</div></div>';
 document.getElementById("quick").innerHTML=`<div class="item"><div><b>Saldo disponível</b><small>Depois dos gastos deste mês</small></div><b class="${bal>=0?"positive":"negative"}">${money(bal)}</b></div><div class="item" style="margin-top:8px"><div><b>Limite de gastos</b><small>${monthlyLimit?"Seu limite mensal":"Ainda não definido"}</small></div><b>${monthlyLimit?money(monthlyLimit-exp):"—"}</b></div>`;
 renderCalendar();renderCharts();renderMiniMonthly();
}
function renderMiniMonthly(){
 const vals=[];for(let i=5;i>=0;i--){const d=new Date(today.getFullYear(),today.getMonth()-i,1),ym=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");vals.push({label:d.toLocaleDateString("pt-BR",{month:"short"}),v:monthlyExpenses(ym).reduce((a,o)=>a+o.x.value,0)})}
 const max=Math.max(...vals.map(x=>x.v),1);document.getElementById("miniMonthly").innerHTML=`<div class="barChart">${vals.map(x=>`<div class="bar" style="height:${Math.max(8,x.v/max*100)}%"><span>${money(x.v)}</span><em>${x.label}</em></div>`).join("")}</div>`;
}

let currentChartMode="pie";
const chartColors=["#22c98a","#ff5268","#1683ff","#ffbf4d","#9b7cff","#55c6d9","#ff8b5c","#8da5bd"];
function setChartMode(mode,btn){
 currentChartMode=mode;
 document.querySelectorAll(".chartMode").forEach(b=>b.classList.toggle("active",b.dataset.chartMode===mode));
 renderCharts();
}
function svgPie(el,data){
 const total=data.reduce((a,x)=>a+Math.max(0,x.v),0);
 if(!total){el.innerHTML='<div class="empty">Ainda não há dados para mostrar.</div>';return}
 let a=-Math.PI/2,paths="";
 data.filter(d=>d.v>0).forEach((d,i)=>{
   const ang=d.v/total*Math.PI*2,x1=50+39*Math.cos(a),y1=50+39*Math.sin(a);a+=ang;
   const x2=50+39*Math.cos(a),y2=50+39*Math.sin(a),large=ang>Math.PI?1:0;
   paths+=`<path d="M50 50 L${x1} ${y1} A39 39 0 ${large} 1 ${x2} ${y2} Z" fill="${chartColors[i%chartColors.length]}" stroke="#061524" stroke-width="1"/>`;
 });
 el.innerHTML=`<svg viewBox="0 0 100 100" class="chartSvgGraphic"><g>${paths}</g><circle cx="50" cy="50" r="19" fill="#061524"/><text x="50" y="47" fill="#8da5bd" font-size="4.5" text-anchor="middle">TOTAL MOV.</text><text x="50" y="54" fill="#fff" font-size="5" text-anchor="middle">${money(data.reduce((a,x)=>a+x.v,0))}</text></svg>`;
}
function svgBars(el,data){
 const max=Math.max(...data.map(x=>Math.max(0,x.v)),1),w=90/data.length;
 el.innerHTML=`<svg viewBox="0 0 100 100" class="chartSvgGraphic"><line x1="4" y1="84" x2="96" y2="84" stroke="#16405f"/>${data.map((d,i)=>{const h=Math.max(2,Math.abs(d.v)/max*62),x=5+i*w,y=84-h;return `<rect x="${x}" y="${y}" width="${Math.max(5,w-4)}" height="${h}" rx="1.5" fill="${chartColors[i%chartColors.length]}"/><text x="${x+w/2}" y="${Math.max(8,y-3)}" fill="#fff" font-size="3.1" text-anchor="middle">${money(d.v)}</text><text x="${x+w/2}" y="93" fill="#8da5bd" font-size="3.2" text-anchor="middle">${esc(d.label).slice(0,10)}</text>`}).join("")}</svg>`;
}
function svgMultiLine(el,series){
 const all=series.flatMap(s=>s.data.map(d=>d.v)),max=Math.max(...all,1),n=series[0]?.data.length||0;
 if(!n){el.innerHTML='<div class="empty">Sem dados.</div>';return}
 const xAt=i=>5+i*(90/Math.max(1,n-1)), yAt=v=>84-(Math.max(0,v)/max*62);
 const lines=series.map((ser,si)=>{
   const pts=ser.data.map((d,i)=>`${xAt(i)},${yAt(d.v)}`).join(" ");
   return `<polyline points="${pts}" fill="none" stroke="${chartColors[si]}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>${ser.data.map((d,i)=>`<circle cx="${xAt(i)}" cy="${yAt(d.v)}" r="1.25" fill="${chartColors[si]}"/>`).join("")}`;
 }).join("");
 const labels=series[0].data.map((d,i)=>`<text x="${xAt(i)}" y="94" fill="#8da5bd" font-size="2.8" text-anchor="middle">${esc(d.label).slice(0,6)}</text>`).join("");
 el.innerHTML=`<svg viewBox="0 0 100 100" class="chartSvgGraphic"><line x1="4" y1="84" x2="96" y2="84" stroke="#16405f"/>${lines}${labels}</svg>`;
}
function renderCharts(){
 const ym=ymNow(), inc=monthlyIncome(ym).reduce((a,o)=>a+o.x.value,0), exp=monthlyExpenses(ym).reduce((a,o)=>a+o.x.value,0), left=inc-exp;
 const safeLeft=Math.max(0,left);
 const totals=document.getElementById("chartTotals");
 if(totals)totals.innerHTML=`<div class="chartTotal income"><span>Recebe</span><b>${money(inc)}</b></div><div class="chartTotal expense"><span>Gasta</span><b>${money(exp)}</b></div><div class="chartTotal leftover"><span>${left>=0?"Sobra":"Falta"}</span><b>${money(Math.abs(left))}</b></div>`;
 const label=document.getElementById("chartMonthLabel");if(label)label.textContent=new Date(today.getFullYear(),today.getMonth(),1).toLocaleDateString("pt-BR",{month:"long",year:"numeric"});
 const oe=document.getElementById("overviewChart");
 const current=[{label:"Recebe",v:inc},{label:"Gasta",v:exp},{label:"Sobra",v:safeLeft}];
 if(currentChartMode==="pie")svgPie(oe,current);else if(currentChartMode==="bar")svgBars(oe,current);else{
   const vals=[];for(let i=11;i>=0;i--){const d=new Date(today.getFullYear(),today.getMonth()-i,1),k=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0"),mi=monthlyIncome(k).reduce((a,o)=>a+o.x.value,0),me=monthlyExpenses(k).reduce((a,o)=>a+o.x.value,0);vals.push({label:d.toLocaleDateString("pt-BR",{month:"short"}),v:mi})}
   const expenseVals=[];const leftVals=[];for(let i=11;i>=0;i--){const d=new Date(today.getFullYear(),today.getMonth()-i,1),k=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0"),mi=monthlyIncome(k).reduce((a,o)=>a+o.x.value,0),me=monthlyExpenses(k).reduce((a,o)=>a+o.x.value,0);expenseVals.push({label:d.toLocaleDateString("pt-BR",{month:"short"}),v:me});leftVals.push({label:d.toLocaleDateString("pt-BR",{month:"short"}),v:Math.max(0,mi-me)});}
   svgMultiLine(oe,[{name:"Recebe",data:vals},{name:"Gasta",data:expenseVals},{name:"Sobra",data:leftVals}]);
 }
 const leg=document.getElementById("overviewLegend");if(leg)leg.innerHTML=`<span><i class="legendDot" style="background:#22c98a"></i>Recebe</span><span><i class="legendDot" style="background:#ff5268"></i>Gasta</span><span><i class="legendDot" style="background:#1683ff"></i>Sobra</span>`;
 const cat={};monthlyExpenses(ym).forEach(o=>cat[o.x.cat]=(cat[o.x.cat]||0)+o.x.value);
 const catData=Object.entries(cat).map(([label,v])=>({label,v})).sort((a,b)=>b.v-a.v),ce=document.getElementById("categoryChart");
 svgPie(ce,catData);
 const cle=document.getElementById("categoryLegend");if(cle)cle.innerHTML=catData.map((d,i)=>`<span><i class="legendDot" style="background:${chartColors[i%chartColors.length]}"></i>${esc(d.label)}: ${money(d.v)}</span>`).join("");
}
function shiftCalendarMonth(delta){
 const input=document.getElementById("calendarMonth");if(!input)return;
 const base=input.value||ymNow(),[y,m]=base.split("-").map(Number),d=new Date(y,m-1+delta,1);
 input.value=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");selectedCalDay=null;renderCalendar();
}
function renderCalendar(){
 const input=document.getElementById("calendarMonth");if(!input.value)input.value=ymNow();const ym=input.value,[y,m]=ym.split("-").map(Number);
 const first=new Date(y,m-1,1).getDay(),days=new Date(y,m,0).getDate(),ex=monthlyExpenses(ym),inc=monthlyIncome(ym);
 const title=document.getElementById("calendarMonthTitle");if(title)title.textContent=new Date(y,m-1,1).toLocaleDateString("pt-BR",{month:"long",year:"numeric"});
 let h=["D","S","T","Q","Q","S","S"].map(x=>`<div class="dow">${x}</div>`).join("");for(let i=0;i<first;i++)h+='<div class="calendarBlank"></div>';
 for(let d=1;d<=days;d++){const ds=`${ym}-${String(d).padStart(2,"0")}`,hasE=ex.some(o=>o.date===ds),hasI=inc.some(o=>o.date===ds),isEnd=inc.some(o=>o.date===ds&&o.x.type==="Benefício"&&o.x.endDate===ds),isToday=ds===new Date().toISOString().slice(0,10),isSelected=selectedCalDay===ds;h+=`<button type="button" class="day ${isToday?"today":""} ${isSelected?"selected":""} ${isEnd?"benefitEndDay":""}" onclick="showDay('${ds}')"><b>${d}</b><div class="dayEvents">${hasI?'<i class="eventDot inc"></i>':''}${hasE?'<i class="eventDot exp"></i>':''}${isEnd?'<i class="eventDot benefitEnd"></i>':''}</div></button>`}
 document.getElementById("calendarGrid").innerHTML=h;
 if(selectedCalDay&&monthKey(selectedCalDay)===ym)showDay(selectedCalDay);else document.getElementById("calendarEvents").innerHTML='<div class="calendarEmpty">Toque em um dia para ver o que você recebe e o que precisa pagar.</div>';
}
function showDay(ds){
 selectedCalDay=ds;const ex=monthlyExpenses(monthKey(ds)).filter(o=>o.date===ds),inc=monthlyIncome(monthKey(ds)).filter(o=>o.date===ds);
 const totalIn=inc.reduce((a,o)=>a+o.x.value,0),totalOut=ex.reduce((a,o)=>a+o.x.value,0);
 let h=`<div class="calendarDayHeader"><div><b>${dateBR(ds)}</b><small>${inc.length+ex.length?"Movimentações do dia":"Nenhuma movimentação cadastrada"}</small></div><strong class="${totalIn-totalOut>=0?"positive":"negative"}">${money(totalIn-totalOut)}</strong></div>`;
 if(inc.length){h+=`<div class="dayGroup incomeGroup"><h3><i class="eventDot inc"></i> Você recebe</h3>`;inc.forEach(o=>h+=`<div class="eventLine"><span>↥ ${esc(o.x.name)}<small>${esc(o.x.type||"Entrada")}</small></span><b class="positive">+ ${money(o.x.value)}</b></div>`);h+='</div>';}
 if(ex.length){h+=`<div class="dayGroup expenseGroup"><h3><i class="eventDot exp"></i> Você paga</h3>`;ex.forEach(o=>h+=`<div class="eventLine"><span>↘ ${esc(o.x.name)}<small>${esc(o.x.cat||"Despesa")}${o.part?` • parcela ${o.part}/${o.x.parts}`:""}</small></span><b class="negative">- ${money(o.x.value)}</b></div>`);h+='</div>';}
 document.getElementById("calendarEvents").innerHTML=h;
 renderCalendarSelectionOnly();
}
function renderCalendarSelectionOnly(){
 const grid=document.getElementById("calendarGrid");if(!grid)return;grid.querySelectorAll(".day").forEach(b=>b.classList.remove("selected"));if(selectedCalDay){const day=Number(selectedCalDay.slice(-2));const buttons=[...grid.querySelectorAll(".day")];const found=buttons.find(b=>Number(b.querySelector("b")?.textContent)===day);if(found)found.classList.add("selected");}
}
function resetData(){if(confirm("Apagar todas as rendas, despesas, metas e limite desta conta?")){expenses=[];incomes=[];goals=[];monthlyLimit=0;save();render();toast("Dados apagados")}}

const sess=JSON.parse(localStorage.getItem("fp1_session")||"null");
if(localStorage.getItem("fp1_logged")==="1"&&sess?.email){userName=sess.name;loadAccount(sess.email,sess.name);document.getElementById("startScreen").classList.add("hidden");document.getElementById("app").style.display="flex"}
else document.getElementById("app").style.display="none";
render();
