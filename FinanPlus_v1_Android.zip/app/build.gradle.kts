plugins { id("com.android.application") }

android {
    namespace = "com.finanplus.v1"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.finanplus.v1"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
